#' an example function
#'
#' @export
test_me <- function(x, y) {
  if (TRUE) { x + y } else { 0 } # nolint
}
